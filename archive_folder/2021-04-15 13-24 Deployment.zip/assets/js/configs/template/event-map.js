﻿/* global app */'use strict';app.eventMap = {
	'launch.skincatalogdeepblueMainBackButton' : [	{ 		action: app.fn.goToUrl, 		argument: 'https://hq.coresystems.hu:9610/skincatalog/index.jsp'	}	],
	'launch.skincatalogdeepblueMainContainerButton' : [	{ 		action: app.fn.showWidgets, 		argument: ['skincatalogdeepblueMainContainer']	}	],
	'launch.skincatalogdeepblueMainContainerButton2' : [	{ 		action: app.fn.showWidget, 		argument: 'skincatalogdeepblueMainContainer2'	}	],
	'launch.skincatalogdeepblueMainContainerButton3' : [	{ 		action: app.fn.showWidget, 		argument: 'skincatalogdeepblueMainContainer3'	}	],
	'launch.skincatalogdeepblueMainContainer4Button' : [	{ 		action: app.fn.showWidgets, 		argument: ['skincatalogdeepblueMainContainer4']	}	],
};
